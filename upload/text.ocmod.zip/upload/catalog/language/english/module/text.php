<?php
$_['heading_title'] = 'Module title';